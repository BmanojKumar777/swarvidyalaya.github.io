import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Music, Mic2, Piano, Guitar, Drum, Clock, Users, Video, Award, Wallet, MessageCircle, ChevronRight, Sparkles, CalendarDays, IndianRupee, Settings2, CheckCircle2, Phone, Youtube, Instagram, Heart, GraduationCap } from 'lucide-react';

type Settings = { upiId: string; whatsapp: string; affiliateTag: string };
type Admission = { name: string; age: string; phone: string; course: string; batch: string; createdLabel: string };
type TeacherApp = { name: string; instrument: string; experience: string; demoLink: string; salary: string; createdLabel: string };

const defaultSettings: Settings = { upiId: '9439204275@ybl', whatsapp: '919439204275', affiliateTag: 'swar-vidyalaya' };
const courses = [
  { name: 'Vocal', tag: 'Sambalpuri • Bollywood • Bhajan', desc: 'Sur, taal aur bhav — gaane ki poori buniyaad, roz riyaaz ke saath.', icon: Mic2, teacher: 'Manoj Bag', duration: '3 Months / Ongoing', color: '#7A1C1C' },
  { name: 'Harmonium', tag: 'Classical + Bhajan Accompaniment', desc: 'Sargam, alankaar aur bhajan accompaniment — haath aur kaan dono taiyaar.', icon: Piano, teacher: 'Teacher Team', duration: '3 Months', color: '#9A5B13' },
  { name: 'Keyboard', tag: 'Modern + Bollywood Playing', desc: 'Chords, rhythm aur Bollywood tunes — pehle hafte se bajana shuru.', icon: Piano, teacher: 'Teacher Team', duration: '3 Months', color: '#7A1C1C' },
  { name: 'Guitar', tag: 'Acoustic • Chords • Strumming', desc: 'Basic se leke full song playing tak — friendly pace, daily practice plan.', icon: Guitar, teacher: 'Teacher Team', duration: '3 Months', color: '#9A5B13' },
  { name: 'Tabla', tag: 'Taal • Kayda • Lehera', desc: 'Teen taal se leke Sambalpuri taal tak — haath ki safai aur lay pakki.', icon: Drum, teacher: 'Teacher Team', duration: '4 Months', color: '#7A1C1C' },
];
const timetable = [
  { time: '4:00 – 5:00 PM', cls: 'Kids Vocal', teacher: 'Teacher Team', days: 'Mon – Sat', live: 'Roz Live' },
  { time: '5:00 – 6:00 PM', cls: 'Guitar', teacher: 'Teacher Team', days: 'Mon – Sat', live: 'Roz Live' },
  { time: '7:00 – 8:00 PM', cls: 'Sambalpuri Special', teacher: 'Manoj Bag', days: 'Tue / Fri', live: 'Special Live' },
  { time: '6:00 – 7:00 PM', cls: 'Harmonium / Keyboard', teacher: 'Teacher Team', days: 'Mon – Sat', live: 'Roz Live' },
  { time: '8:00 – 9:00 PM', cls: 'Bhajan & Bollywood Vocal', teacher: 'Manoj Bag', days: 'Sat / Sun', live: 'Weekend Live' },
];

async function api(action: string, args: Record<string, unknown>) {
  const res = await fetch('actions', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json?.error) throw new Error(json?.error || `Request failed (${res.status})`);
  return json.data;
}

export default function App() {
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [settingsId, setSettingsId] = useState<string | null>(null);
  const [settingsNote, setSettingsNote] = useState('School ki official details — yahin se UPI aur WhatsApp update hota hai.');
  const [admissions, setAdmissions] = useState<Admission[]>([]);
  const [teachers, setTeachers] = useState<TeacherApp[]>([]);
  const [loadNote, setLoadNote] = useState('');
  const [students, setStudents] = useState(50);
  const [activeCourse, setActiveCourse] = useState('Vocal');
  const [admission, setAdmission] = useState({ name: '', age: '', phone: '', course: 'Vocal', batch: '4–5 PM • Kids Vocal' });
  const [teacherForm, setTeacherForm] = useState({ name: '', instrument: 'Vocal', experience: '', demoLink: '', salary: '₹10,000 – ₹15,000' });
  const [busy, setBusy] = useState<'admission' | 'teacher' | 'settings' | null>(null);
  const [admissionDone, setAdmissionDone] = useState<Admission | null>(null);
  const [teacherDone, setTeacherDone] = useState<TeacherApp | null>(null);
  const [formError, setFormError] = useState('');
  const [logoTap, setLogoTap] = useState(false);
  const admissionRef = useRef<HTMLDivElement>(null);
  const teacherRef = useRef<HTMLDivElement>(null);

  const loadRecords = async () => {
    try {
      const [a, t, s] = await Promise.all([
        api('records.list', { collection: 'swar_admissions' }),
        api('records.list', { collection: 'swar_teacher_applications' }),
        api('records.list', { collection: 'swar_settings' }),
      ]);
      setAdmissions((a?.records || []).map((r: any) => r.value));
      setTeachers((t?.records || []).map((r: any) => r.value));
      if (s?.records?.length) { setSettings(s.records[0].value); setSettingsId(s.records[0].id); }
    } catch { setLoadNote('Records abhi load nahi ho rahe — form bharne par phir se try karein.'); }
  };
  useEffect(() => { loadRecords(); }, []);

  const upiLink = `upi://pay?pa=${encodeURIComponent(settings.upiId)}&pn=${encodeURIComponent('Manoj Bag Swar Vidyalaya')}&am=999&cu=INR&tn=${encodeURIComponent('Monthly Music Class Fee')}`;
  const waText = (msg: string) => `https://wa.me/${settings.whatsapp}?text=${encodeURIComponent(msg)}`;
  const revenue = students * 999;
  const teacherShare = Math.round(revenue * 0.6);
  const schoolShare = revenue - teacherShare;

  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  const enroll = (name: string) => { setAdmission(a => ({ ...a, course: name })); setActiveCourse(name); scrollTo('admission'); };

  async function submitAdmission(e: React.FormEvent) {
    e.preventDefault(); setFormError('');
    if (!admission.name.trim() || !admission.phone.trim() || !admission.age.trim()) { setFormError('Naam, umar aur phone — teeno zaroori hain.'); return; }
    if (!/^[0-9+ -]{8,}$/.test(admission.phone.trim())) { setFormError('Phone number sahi se likhein.'); return; }
    setBusy('admission');
    const value: Admission = { ...admission, createdLabel: new Date().toLocaleString('en-IN') };
    try {
      await api('records.create', { collection: 'swar_admissions', value, idempotency_key: `admission-${admission.phone.trim()}-${admission.name.trim()}-${Date.now()}` });
      await loadRecords(); setAdmissionDone(value); setAdmission({ name: '', age: '', phone: '', course: admission.course, batch: admission.batch });
    } catch (err) { setFormError(err instanceof Error ? err.message : 'Admission save nahi hui. Phir se try karein.'); }
    setBusy(null);
  }
  async function submitTeacher(e: React.FormEvent) {
    e.preventDefault(); setFormError('');
    if (!teacherForm.name.trim() || !teacherForm.experience.trim()) { setFormError('Naam aur experience likhna zaroori hai.'); return; }
    setBusy('teacher');
    const value: TeacherApp = { ...teacherForm, createdLabel: new Date().toLocaleString('en-IN') };
    try {
      await api('records.create', { collection: 'swar_teacher_applications', value, idempotency_key: `teacher-${teacherForm.name.trim()}-${Date.now()}` });
      await loadRecords(); setTeacherDone(value); setTeacherForm({ name: '', instrument: 'Vocal', experience: '', demoLink: '', salary: '₹10,000 – ₹15,000' });
    } catch (err) { setFormError(err instanceof Error ? err.message : 'Application save nahi hui. Phir se try karein.'); }
    setBusy(null);
  }
  async function saveSettings(e: React.FormEvent) {
    e.preventDefault(); setBusy('settings');
    try {
      if (settingsId) await api('records.replace', { collection: 'swar_settings', id: settingsId, value: settings });
      else { const created: any = await api('records.create', { collection: 'swar_settings', value: settings, idempotency_key: 'swar-settings-v1' }); setSettingsId(created?.id || null); }
      setSettingsNote('Settings save ho gaye. UPI aur WhatsApp links ab naye details se khulenge.');
      await loadRecords();
    } catch (err) { setSettingsNote(err instanceof Error ? err.message : 'Settings save nahi hue.'); }
    setBusy(null);
  }
  const admissionWhatsApp = admissionDone ? waText(`Namaste! Main ${admissionDone.name} hoon. ${admissionDone.course} (${admissionDone.batch}) ke liye admission ho gaya hai. Mujhe WhatsApp group me add karein.`) : '#';
  const teacherWhatsApp = teacherDone ? waText(`Namaste! Main ${teacherDone.name} hoon. ${teacherDone.instrument} teacher ke liye apply kiya hai. Experience: ${teacherDone.experience}.`) : '#';
  const meetLink = 'https://meet.google.com/new';

  return (
    <div id="top" data-safe-area-inset-root style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)', minHeight: '100vh', background: 'var(--surface)' }} className="overflow-x-clip">
      {/* TOP BAR */}
      <div className="bg-[#1A0F0F] text-[#FFF8E1] text-[12px] sm:text-[13px]"><div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap justify-between gap-2"><span>✦ Ghar Baithe Music Seekho — Online Live Classes</span><span className="hidden sm:inline">Founder: Manoj Kumar Bag • Mulank 5 • Bhagyank 5 • Double Mercury</span><a href="https://wa.me/919439204275" target="_blank" rel="noopener" className="underline decoration-[#FFD700]">WhatsApp: +91 9439204275</a></div></div>

      {/* HEADER */}
      <header data-safe-area-sticky-top style={{ top: 'var(--safe-area-inset-top)' }} className="sticky z-40 bg-[#FFF8E1]/95 backdrop-blur border-b border-[#E8D9A8]">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <a href="#top" onClick={() => { setLogoTap(true); }} className="flex items-center gap-3 text-left" aria-label="Swar Vidyalaya home par jayein">
            <span className={`w-11 h-11 rounded-full bg-[#7A1C1C] text-[#FFD700] grid place-items-center font-display text-2xl shadow ${logoTap ? 'ring-4 ring-[#FFD700]' : ''}`}>म</span>
            <span><span className="block font-display font-bold leading-none text-[#7A1C1C] text-[17px] sm:text-xl">MANOJ BAG</span><span className="block text-[10px] sm:text-[11px] tracking-[0.22em] font-bold text-[#9A5B13]">{logoTap ? 'SWAR VIDYALAYA • HOME ✓' : 'SWAR VIDYALAYA • ONLINE MUSIC SCHOOL'}</span></span>
          </a>
          <nav className="hidden lg:flex gap-5 text-sm font-semibold text-[#4A0F0F]">
            <button onClick={() => scrollTo('courses')}>Courses</button><button onClick={() => scrollTo('timetable')}>Timetable</button><button onClick={() => scrollTo('how')}>Kaise Seekhenge?</button><button onClick={() => scrollTo('fees')}>Fees</button><button onClick={() => scrollTo('teacher')}>Teacher Banein</button>
          </nav>
          <div className="flex gap-2"><button onClick={() => scrollTo('admission')} className="bg-[#7A1C1C] text-white px-3 sm:px-4 py-2.5 rounded-full text-xs sm:text-sm font-bold">Student Admission</button><button onClick={() => scrollTo('teacher')} className="hidden sm:block border-2 border-[#7A1C1C] text-[#7A1C1C] px-4 py-2.5 rounded-full text-sm font-bold">Teacher Apply</button></div>
        </div>
      </header>

      {/* HERO */}
      <section className="bg-[#7A1C1C] text-[#FFF8E1] pattern relative overflow-x-clip">
        <div className="max-w-7xl mx-auto px-4 py-10 sm:py-16 grid lg:grid-cols-[1.25fr_.75fr] gap-8 items-center">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/10 border border-[#FFD700]/50 rounded-full px-3 py-1.5 text-xs font-bold tracking-wide"><Sparkles size={15} className="text-[#FFD700]" /> ROZ LIVE CLASSES • 100% ONLINE</div>
            <p className="font-hindi text-[#FFD700] text-2xl mt-5">संगीत घर बैठे, दिल से सीखो</p>
            <h1 className="font-display text-[42px] leading-[0.92] sm:text-7xl font-black mt-2">MANOJ BAG<br /><span className="gold-text">SWAR VIDYALAYA</span></h1>
            <p className="text-lg sm:text-2xl mt-4 font-medium">Online Music School — <b>Roz Live Classes</b></p>
            <p className="text-white/80 max-w-xl mt-3 leading-relaxed">Sambalpuri ki mitti se Bollywood tak. Bachchon se leke bado tak — sur, taal aur riyaaz, ab ghar baithe, live teacher ke saath.</p>
            <div className="flex flex-wrap gap-3 mt-7"><button onClick={() => scrollTo('admission')} className="bg-[#FFD700] text-[#1A0F0F] px-6 py-3.5 rounded-full font-bold shadow-lg">Student Admission — ₹999/mo →</button><button onClick={() => scrollTo('teacher')} className="border border-white/50 px-6 py-3.5 rounded-full font-bold">Teacher Apply</button></div>
            <div className="grid grid-cols-3 max-w-xl gap-3 mt-8"><div className="bg-white/10 rounded-2xl p-3"><div className="text-2xl font-display font-bold">3</div><div className="text-xs text-white/75">Teachers</div></div><div className="bg-white/10 rounded-2xl p-3"><div className="text-2xl font-display font-bold">Daily</div><div className="text-xs text-white/75">Live Classes</div></div><div className="bg-white/10 rounded-2xl p-3"><div className="text-2xl font-display font-bold">100%</div><div className="text-xs text-white/75">Online</div></div></div>
          </div>
          <aside className="bg-[#FFF8E1] text-[#1A0F0F] rounded-[28px] p-5 sm:p-6 shadow-2xl rotate-0 sm:rotate-1">
            <div className="flex justify-between items-start"><div><p className="text-xs tracking-[0.2em] font-bold text-[#9A5B13]">FOUNDER'S NOTE</p><h2 className="font-display text-3xl font-bold text-[#7A1C1C] mt-1">Manoj Kumar Bag</h2><p className="text-sm text-[#6D564E]">DOB: 05-10-1979 • Mulank 5 • Bhagyank 5</p></div><span className="text-5xl">🎼</span></div>
            <p className="font-hindi text-lg leading-relaxed mt-4">“Sangeet sirf seekha nahi jaata, jiya jaata hai. Har bachche ke andar ek sur chhupa hai — bas sahi guru aur roz ka riyaaz chahiye.”</p>
            <div className="mt-5 bg-[#7A1C1C] text-white rounded-2xl p-4 flex justify-between items-center"><div><p className="text-xs text-white/70">Aaj ka special</p><p className="font-bold">Sambalpuri Special • Tue / Fri • 7–8 PM</p></div><a href={meetLink} target="_blank" rel="noopener" className="bg-[#FFD700] text-black text-xs font-bold px-3 py-2 rounded-full whitespace-nowrap">Join Live ↗</a></div>
            <p className="text-center text-xs mt-3 text-[#6D564E]">Dheere Dheere Improve Karenge — Version 1.0</p>
          </aside>
        </div>
        <div className="bg-[#FFD700] text-[#1A0F0F] text-center text-xs sm:text-sm font-bold py-2 px-4">✦ Admission ₹499 + Monthly ₹999 + Certificate ₹999 — Koi chhupa hua charge nahi ✦</div>
      </section>

      <main className="max-w-7xl mx-auto px-4">
        {/* COURSES */}
        <section id="courses" className="py-12 sm:py-16">
          <div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-[#9A5B13] font-bold tracking-widest text-xs">COURSES • पाठ्यक्रम</p><h2 className="font-display text-4xl sm:text-5xl font-bold text-[#7A1C1C] mt-2">Kya seekhna hai?</h2></div><p className="text-[#6D564E] max-w-md">Har course live hota hai. Ek course chunein, batch chunein — aur kal se riyaaz shuru.</p></div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-7">
            {courses.map(c => <article key={c.name} className={`bg-white rounded-3xl border p-5 shadow-sm transition ${activeCourse === c.name ? 'border-[#FFD700] ring-2 ring-[#FFD700]/60' : 'border-[#E8D9A8]'}`}>
              <div className="flex justify-between"><span className="w-12 h-12 rounded-2xl grid place-items-center text-white" style={{ background: c.color }}><c.icon /></span><span className="bg-[#FFF8E1] text-[#7A1C1C] px-3 py-1 rounded-full text-xs font-bold h-fit">{c.duration}</span></div>
              <h3 className="font-display text-2xl font-bold mt-4">{c.name}</h3><p className="text-sm font-bold text-[#9A5B13]">{c.tag}</p><p className="text-sm text-[#6D564E] leading-relaxed mt-2 min-h-[63px]">{c.desc}</p>
              <div className="flex justify-between items-center mt-4 pt-4 border-t border-dashed"><div><p className="text-xs text-[#6D564E]">Teacher • {c.teacher}</p><p className="font-display text-2xl font-bold">₹999<span className="text-sm font-sans font-normal text-[#6D564E]"> /month</span></p></div><button onClick={() => enroll(c.name)} className="bg-[#7A1C1C] text-white px-4 py-2.5 rounded-full text-sm font-bold">Enroll (UPI) →</button></div>
            </article>)}
            <div className="bg-[#1A0F0F] text-white rounded-3xl p-6 flex flex-col justify-between"><Music className="text-[#FFD700]" /><h3 className="font-display text-2xl font-bold mt-4">Confused hain?<br />Free demo class lein.</h3><p className="text-white/70 text-sm mt-2">Ek live class dekh kar decide karein. Koi pressure nahi.</p><a href={waText('Namaste! Mujhe ek free demo class chahiye.')} target="_blank" rel="noopener" className="mt-5 bg-[#FFD700] text-black text-center py-3 rounded-full font-bold">WhatsApp par Demo Maangein</a></div>
          </div>
        </section>

        {/* TIMETABLE */}
        <section id="timetable" className="pb-14">
          <div className="bg-white rounded-[28px] border border-[#E8D9A8] overflow-hidden shadow-sm">
            <div className="p-5 sm:p-7 flex flex-wrap justify-between gap-4 items-center bg-[#FFF8E1]"><div><p className="text-xs tracking-widest font-bold text-[#9A5B13]">DAILY TIMETABLE • रोज़ का समय</p><h2 className="font-display text-3xl sm:text-4xl font-bold text-[#7A1C1C]">Roz ka riyaaz, fix time par</h2></div><a href={meetLink} target="_blank" rel="noopener" className="bg-[#1A0F0F] text-white px-4 py-3 rounded-full text-sm font-bold flex gap-2 items-center"><Video size={17} /> Google Meet — Live Link</a></div>
            <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-left text-sm"><thead className="bg-[#7A1C1C] text-white"><tr><th className="p-4">Time</th><th className="p-4">Class</th><th className="p-4">Teacher</th><th className="p-4">Days</th><th className="p-4">Status</th></tr></thead><tbody>{timetable.map((r, i) => <tr key={r.cls} className={i % 2 ? 'bg-[#FFF8E1]/60' : ''}><td className="p-4 font-bold whitespace-nowrap"><Clock className="inline mr-1 text-[#9A5B13]" size={15} />{r.time}</td><td className="p-4 font-bold">{r.cls}</td><td className="p-4">{r.teacher}</td><td className="p-4">{r.days}</td><td className="p-4"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-bold">{r.live}</span></td></tr>)}</tbody></table></div>
            <p className="p-4 text-xs text-[#6D564E]">Class link admission ke baad WhatsApp group me roz bheja jayega. Link placeholder: meet.google.com/new — final link group me milega.</p>
          </div>
        </section>

        {/* ADMISSION + TEACHER */}
        <section id="admission" ref={admissionRef} className="grid lg:grid-cols-2 gap-5 pb-14">
          <div className="bg-[#7A1C1C] text-white rounded-[28px] p-5 sm:p-7">
            <span className="bg-[#FFD700] text-black text-xs font-bold px-3 py-1 rounded-full">STUDENT ADMISSION</span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold mt-4">Admission — 2 minute me</h2><p className="text-white/80 text-sm mt-2">Form bhariye → UPI se ₹999 pay karein → WhatsApp group me add ho jaiye.</p>
            {!admissionDone ? <form onSubmit={submitAdmission} className="mt-6 space-y-3">
              <label className="block text-sm font-bold">Student ka Naam<input required value={admission.name} onChange={e => setAdmission({ ...admission, name: e.target.value })} placeholder="Poora naam" className="mt-1 w-full rounded-xl px-4 py-3 text-black border border-white/30" /></label>
              <div className="grid grid-cols-2 gap-3"><label className="block text-sm font-bold">Age<input required value={admission.age} onChange={e => setAdmission({ ...admission, age: e.target.value })} inputMode="numeric" placeholder="e.g. 10" className="mt-1 w-full rounded-xl px-4 py-3 text-black" /></label><label className="block text-sm font-bold">Phone / WhatsApp<input required value={admission.phone} onChange={e => setAdmission({ ...admission, phone: e.target.value })} placeholder="10-digit mobile" className="mt-1 w-full rounded-xl px-4 py-3 text-black" /></label></div>
              <div className="grid sm:grid-cols-2 gap-3"><label className="block text-sm font-bold">Course<select value={admission.course} onChange={e => setAdmission({ ...admission, course: e.target.value })} className="mt-1 w-full rounded-xl px-3 py-3 text-black">{courses.map(c => <option key={c.name}>{c.name}</option>)}</select></label><label className="block text-sm font-bold">Batch<select value={admission.batch} onChange={e => setAdmission({ ...admission, batch: e.target.value })} className="mt-1 w-full rounded-xl px-3 py-3 text-black"><option>4–5 PM • Kids Vocal</option><option>5–6 PM • Guitar</option><option>6–7 PM • Harmonium / Keyboard</option><option>7–8 PM • Sambalpuri Special</option><option>8–9 PM • Bhajan & Bollywood</option></select></label></div>
              {formError && <p className="bg-white/15 rounded-xl px-3 py-2 text-sm">{formError}</p>}
              <button disabled={busy === 'admission'} className="w-full bg-[#FFD700] text-black font-bold py-3.5 rounded-full disabled:opacity-60">{busy === 'admission' ? 'Save ho raha hai…' : 'Admission Confirm Karein →'}</button>
              <p className="text-center text-xs text-white/70">Admission save hote hi UPI payment box khulega.</p>
            </form> : <div className="mt-6 bg-white text-[#1A0F0F] rounded-2xl p-5">
              <div className="flex gap-2 items-center text-green-700 font-bold"><CheckCircle2 /> Admission Successful!</div>
              <p className="mt-2 text-sm"><b>{admissionDone.name}</b> — {admissionDone.course} • {admissionDone.batch}</p>
              <p className="text-sm mt-1">WhatsApp Group me add kar diya jayega. Ab ₹999 monthly fee pay karein:</p>
              <div className="mt-4 border-2 border-dashed border-[#7A1C1C] rounded-2xl p-4 text-center"><div className="text-4xl">📱</div><p className="font-bold mt-2">UPI ID: {settings.upiId}</p><p className="text-2xl font-display font-bold">₹999</p><p className="text-xs text-[#6D564E]">UPI app me ID daal kar pay karein ya neeche button dabayein</p><a href={upiLink} className="inline-block mt-3 bg-[#7A1C1C] text-white px-5 py-3 rounded-full font-bold">UPI App me ₹999 Pay Karein</a></div>
              <a href={admissionWhatsApp} target="_blank" rel="noopener" className="mt-3 flex items-center justify-center gap-2 bg-[#25D366] text-[#07330F] font-bold py-3 rounded-full"><MessageCircle size={18} /> WhatsApp Group Join Message Bhejein</a>
              <button onClick={() => setAdmissionDone(null)} className="w-full mt-2 text-sm font-bold underline">Ek aur admission karein</button>
            </div>}
          </div>

          <div id="teacher" ref={teacherRef} className="bg-white rounded-[28px] border border-[#E8D9A8] p-5 sm:p-7">
            <span className="bg-[#FFF1C4] text-[#7A1C1C] text-xs font-bold px-3 py-1 rounded-full">TEACHER APPLY</span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#7A1C1C] mt-4">Ghar Baithe Padhayein,<br />₹10,000–15,000 Kamayein</h2>
            <p className="text-sm text-[#6D564E] mt-2">Apna talent ghar se duniya tak pahunchayein. Demo ke baad onboarding hoga.</p>
            {!teacherDone ? <form onSubmit={submitTeacher} className="mt-5 space-y-3">
              <label className="block text-sm font-bold">Aapka Naam<input required value={teacherForm.name} onChange={e => setTeacherForm({ ...teacherForm, name: e.target.value })} placeholder="Poora naam" className="w-full mt-1 border rounded-xl px-4 py-3" /></label>
              <div className="grid grid-cols-2 gap-3"><label className="block text-sm font-bold">Instrument<select value={teacherForm.instrument} onChange={e => setTeacherForm({ ...teacherForm, instrument: e.target.value })} className="w-full mt-1 border rounded-xl px-3 py-3">{courses.map(c => <option key={c.name}>{c.name}</option>)}</select></label><label className="block text-sm font-bold">Experience<input required value={teacherForm.experience} onChange={e => setTeacherForm({ ...teacherForm, experience: e.target.value })} placeholder="e.g. 5 saal" className="w-full mt-1 border rounded-xl px-4 py-3" /></label></div>
              <label className="block text-sm font-bold">Demo Video Link<input value={teacherForm.demoLink} onChange={e => setTeacherForm({ ...teacherForm, demoLink: e.target.value })} placeholder="YouTube / Drive link" className="w-full mt-1 border rounded-xl px-4 py-3" /></label>
              <label className="block text-sm font-bold">Expected Salary<select value={teacherForm.salary} onChange={e => setTeacherForm({ ...teacherForm, salary: e.target.value })} className="w-full mt-1 border rounded-xl px-3 py-3"><option>₹10,000 – ₹15,000</option><option>₹8,000 – ₹10,000</option><option>₹15,000+</option></select></label>
              <button disabled={busy === 'teacher'} className="w-full bg-[#1A0F0F] text-white font-bold py-3.5 rounded-full disabled:opacity-60">{busy === 'teacher' ? 'Bhej rahe hain…' : 'Application Bhejein'}</button>
            </form> : <div className="mt-5 bg-[#FFF8E1] border border-[#E8D9A8] rounded-2xl p-5"><div className="flex gap-2 text-green-700 font-bold"><CheckCircle2 /> Application Received!</div><p className="text-sm mt-2">Dhanyavaad, <b>{teacherDone.name}</b> ji. {teacherDone.instrument} ke liye aapki application mil gayi. Demo review ke baad team contact karegi.</p><a href={teacherWhatsApp} target="_blank" rel="noopener" className="mt-4 flex justify-center gap-2 bg-[#25D366] text-[#07330F] font-bold py-3 rounded-full"><MessageCircle size={18} /> WhatsApp par Apply Karein</a><button onClick={() => setTeacherDone(null)} className="w-full mt-2 text-sm font-bold underline">Ek aur application</button></div>}
            <div className="mt-5 bg-[#FFF8E1] rounded-2xl p-4"><p className="font-bold text-sm">Teacher Commission Model</p><div className="flex gap-2 mt-3 text-center text-sm"><div className="flex-1 bg-white rounded-xl p-3"><b className="text-xl">60%</b><br />Teacher</div><div className="flex-1 bg-white rounded-xl p-3"><b className="text-xl">40%</b><br />School</div><div className="flex-1 bg-white rounded-xl p-3"><b className="text-xl">5th</b><br />Payment Date</div></div><p className="text-xs text-[#6D564E] mt-2">Har mahine ki 5 tareekh ko payment. Transparent hisaab, har mahine.</p></div>
          </div>
        </section>

        {/* HOW IT WORKS + TEAM */}
        <section id="how" className="pb-14">
          <p className="text-xs tracking-widest font-bold text-[#9A5B13]">HOW IT WORKS • KAISE KAAM KAREGA?</p><h2 className="font-display text-4xl font-bold text-[#7A1C1C] mt-2">4 steps me shuru</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">{[{ n: '1', t: 'Admission', d: 'Form + ₹999 UPI payment. Seat confirm.' }, { n: '2', t: 'WhatsApp Group', d: 'Class group me add — notes, riyaaz, updates.' }, { n: '3', t: 'Daily Live Link', d: 'Roz Google Meet link — same time, live class.' }, { n: '4', t: 'Certificate', d: 'Course poora hone par certificate — ₹999.' }].map(s => <div key={s.n} className="bg-white border border-[#E8D9A8] rounded-3xl p-5"><span className="text-5xl font-display font-black text-[#FFD700]">{s.n}</span><h3 className="font-bold text-xl mt-2">{s.t}</h3><p className="text-sm text-[#6D564E] mt-1">{s.d}</p></div>)}</div>
          <div className="mt-5 bg-[#1A0F0F] text-white rounded-[28px] p-5 sm:p-7 grid md:grid-cols-4 gap-5"><div><GraduationCap className="text-[#FFD700]" /><h3 className="font-bold mt-2">Founder</h3><p className="text-sm text-white/70">Manoj Bag — Vision, Sambalpuri Special</p></div><div><Users className="text-[#FFD700]" /><h3 className="font-bold mt-2">Manager</h3><p className="text-sm text-white/70">Admissions, batches aur daily coordination</p></div><div><Music className="text-[#FFD700]" /><h3 className="font-bold mt-2">Teachers</h3><p className="text-sm text-white/70">Vocal • Harmonium • Keyboard • Guitar • Tabla</p></div><div><Sparkles className="text-[#FFD700]" /><h3 className="font-bold mt-2">Social Media</h3><p className="text-sm text-white/70">Reels, class clips aur student stories</p></div></div>
        </section>

        {/* FEES + CALCULATOR */}
        <section id="fees" className="pb-14 grid lg:grid-cols-[.9fr_1.1fr] gap-5">
          <div className="bg-[#FFF1C4] rounded-[28px] p-5 sm:p-7 border border-[#E8D9A8]"><p className="text-xs tracking-widest font-bold text-[#9A5B13]">FEES • TRANSPARENT</p><h2 className="font-display text-3xl sm:text-4xl font-bold text-[#7A1C1C] mt-2">Koi chhupa charge nahi</h2><div className="space-y-3 mt-6">{[['Admission (ek baar)', '₹499'], ['Monthly Fee', '₹999'], ['Certificate', '₹999']].map(([a, b]) => <div key={a} className="bg-white rounded-2xl p-4 flex justify-between font-bold"><span>{a}</span><span className="text-[#7A1C1C]">{b}</span></div>)}</div><p className="text-sm text-[#6D564E] mt-4">Pehle mahine ka total: <b>₹1,498</b> (Admission ₹499 + Monthly ₹999). Certificate course ke ant me.</p><a href={upiLink} className="mt-4 flex justify-center gap-2 bg-[#7A1C1C] text-white py-3 rounded-full font-bold"><IndianRupee size={18} /> UPI se Fee Pay Karein</a></div>
          <div className="bg-white rounded-[28px] p-5 sm:p-7 border border-[#E8D9A8]"><div className="flex justify-between items-center"><div><p className="text-xs tracking-widest font-bold text-[#9A5B13]">INCOME CALCULATOR</p><h2 className="font-display text-3xl font-bold text-[#7A1C1C] mt-1">School ka hisaab</h2></div><span className="text-3xl">🧮</span></div><label className="block mt-6 font-bold">Students: <span className="text-[#7A1C1C] text-2xl">{students}</span><input type="range" min="5" max="200" step="5" value={students} onChange={e => setStudents(Number(e.target.value))} className="w-full accent-[#7A1C1C] mt-2" /></label><div className="grid grid-cols-3 gap-3 mt-5 text-center">{[['Monthly Income', `₹${revenue.toLocaleString('en-IN')}`], ['Teacher Share (60%)', `₹${teacherShare.toLocaleString('en-IN')}`], ['School Share (40%)', `₹${schoolShare.toLocaleString('en-IN')}`]].map(([a, b]) => <div key={a} className="bg-[#FFF8E1] rounded-2xl p-3"><p className="text-[11px] text-[#6D564E]">{a}</p><p className="font-bold text-[#7A1C1C] mt-1">{b}</p></div>)}</div><p className="mt-4 bg-[#FFF8E1] rounded-xl p-3 text-sm">Example: <b>50 students = ₹49,950</b> monthly. Slider ghumayein — hisaab turant badlega.</p><div className="flex flex-wrap gap-3 mt-4 text-sm"><span className="bg-[#FFF8E1] px-3 py-2 rounded-full">📚 Saved admissions: <b>{admissions.length}</b></span><span className="bg-[#FFF8E1] px-3 py-2 rounded-full">👩‍🏫 Teacher applications: <b>{teachers.length}</b></span></div>{loadNote && <p className="text-xs text-[#6D564E] mt-3">{loadNote}</p>}</div>
        </section>

        {/* SETTINGS */}
        <section className="pb-14">
          <div className="bg-[#1A0F0F] text-white rounded-[28px] p-5 sm:p-7 grid lg:grid-cols-[.8fr_1.2fr] gap-6"><div><Settings2 className="text-[#FFD700]" /><h2 className="font-display text-3xl font-bold mt-2">Settings Panel</h2><p className="text-white/70 text-sm mt-2">UPI ID, WhatsApp number aur affiliate tag yahin se badlein. Save hote hi poori site par naye details lagu ho jayenge.</p><p className="text-xs mt-4 bg-white/10 rounded-xl p-3">Current: UPI <b>{settings.upiId}</b> • WhatsApp <b>+{settings.whatsapp}</b> • Tag <b>{settings.affiliateTag}</b></p></div>
          <form onSubmit={saveSettings} className="grid sm:grid-cols-3 gap-3 content-start"><label className="text-sm font-bold">UPI ID<input value={settings.upiId} onChange={e => setSettings({ ...settings, upiId: e.target.value })} className="w-full mt-1 rounded-xl px-3 py-3 text-black" /></label><label className="text-sm font-bold">WhatsApp Number<input value={settings.whatsapp} onChange={e => setSettings({ ...settings, whatsapp: e.target.value })} className="w-full mt-1 rounded-xl px-3 py-3 text-black" /></label><label className="text-sm font-bold">Affiliate Tag<input value={settings.affiliateTag} onChange={e => setSettings({ ...settings, affiliateTag: e.target.value })} className="w-full mt-1 rounded-xl px-3 py-3 text-black" /></label><button disabled={busy === 'settings'} className="sm:col-span-3 bg-[#FFD700] text-black font-bold py-3 rounded-full disabled:opacity-60">{busy === 'settings' ? 'Save ho raha hai…' : 'Settings Save Karein'}</button><p className="sm:col-span-3 text-xs text-white/70">{settingsNote}</p></form></div>
        </section>
      </main>

      <footer className="bg-[#1A0F0F] text-white">
        <div className="max-w-7xl mx-auto px-4 py-10 grid md:grid-cols-4 gap-7"><div><h3 className="font-display text-2xl font-bold">MANOJ BAG<br /><span className="text-[#FFD700]">SWAR VIDYALAYA</span></h3><p className="text-white/70 text-sm mt-2">Ghar Baithe Music Seekho — Online Live Classes</p></div><div><h4 className="font-bold">Contact</h4><p className="text-sm text-white/70 mt-2">Founder: Manoj Kumar Bag<br />WhatsApp: +91 9439204275<br />UPI: {settings.upiId}</p></div><div><h4 className="font-bold">Quick Links</h4><div className="flex flex-col gap-1 text-sm text-white/70 mt-2 text-left"><button onClick={() => scrollTo('courses')} className="text-left">Courses</button><button onClick={() => scrollTo('timetable')} className="text-left">Timetable</button><button onClick={() => scrollTo('admission')} className="text-left">Admission</button><button onClick={() => scrollTo('teacher')} className="text-left">Teacher Apply</button></div></div><div><h4 className="font-bold">Follow</h4><div className="flex gap-2 mt-3"><a href={waText('Namaste! Swar Vidyalaya ke baare me jaankari chahiye.')} target="_blank" rel="noopener" className="bg-white/10 px-3 py-2 rounded-full text-sm flex gap-1 items-center"><MessageCircle size={15} /> WhatsApp</a><a href="https://youtube.com" target="_blank" rel="noopener" className="bg-white/10 px-3 py-2 rounded-full text-sm flex gap-1 items-center"><Youtube size={15} /> YouTube</a><a href="https://instagram.com" target="_blank" rel="noopener" className="bg-white/10 px-3 py-2 rounded-full text-sm flex gap-1 items-center"><Instagram size={15} /> Instagram</a></div><p className="text-xs text-white/50 mt-3">Class clips, bhajan aur student performances.</p></div></div>
        <div className="border-t border-white/10 text-center text-xs text-white/60 py-4 px-4 flex flex-wrap justify-center gap-2"><span>© Manoj Bag Swar Vidyalaya</span><span>•</span><span className="text-[#FFD700]">Dheere Dheere Improve Karenge — Version 1.0</span><span>•</span><span className="flex items-center gap-1">Made with <Heart size={12} className="text-[#FFD700]" /> aur sur ke saath</span></div>
      </footer>

      {/* STICKY MOBILE CTA */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur border-t border-[#E8D9A8] p-3 flex gap-2 sm:hidden"><button onClick={() => scrollTo('admission')} className="flex-1 bg-[#7A1C1C] text-white py-3 rounded-full font-bold text-sm">Admission — ₹999</button><a href={waText('Namaste! Admission ke baare me baat karni hai.')} target="_blank" rel="noopener" className="flex-1 bg-[#25D366] text-[#07330F] py-3 rounded-full font-bold text-sm text-center">WhatsApp</a></div>
      <div className="h-16 sm:hidden bg-[#1A0F0F]" />
    </div>
  );
}
